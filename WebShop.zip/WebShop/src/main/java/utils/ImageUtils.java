package utils;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.Part;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

public class ImageUtils {

    private static final Path IMAGE_DIR = Paths.get(ConstantUtils.IMAGE_PATH);

    /**
     * Upload image từ request
     * @return tên file ảnh nếu upload thành công, null nếu không có ảnh
     */
    public static String upload(HttpServletRequest request) {

        try {
            Part filePart = request.getPart("image");

            if (filePart == null || filePart.getSize() == 0) {
                return null;
            }

            String contentType = filePart.getContentType();
            if (contentType == null || !contentType.startsWith("image")) {
                return null;
            }

            // tạo thư mục nếu chưa tồn tại
            if (!Files.exists(IMAGE_DIR)) {
                Files.createDirectories(IMAGE_DIR);
            }

            // tạo file ảnh ngẫu nhiên
            Path targetLocation = Files.createTempFile(IMAGE_DIR, "img-", ".jpg");

            InputStream fileContent = filePart.getInputStream();
            Files.copy(fileContent, targetLocation, StandardCopyOption.REPLACE_EXISTING);
            fileContent.close();

            return targetLocation.getFileName().toString();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }

    /**
     * Xóa ảnh theo tên file
     */
    public static void delete(String imageName) {

        if (imageName == null || imageName.trim().isEmpty()) {
            return;
        }

        Path imagePath = IMAGE_DIR.resolve(imageName).normalize();

        try {
            boolean deleted = Files.deleteIfExists(imagePath);
            if (deleted) {
                System.out.println("Deleted image: " + imageName);
            } else {
                System.out.println("Image not found: " + imageName);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
