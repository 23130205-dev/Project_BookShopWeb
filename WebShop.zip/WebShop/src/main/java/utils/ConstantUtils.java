package utils;

public final class ConstantUtils {
    private ConstantUtils() {} // Ngăn tạo instance

    // Database config
    public static final int DB_PORT = 3306;
    public static final String SERVER_NAME = "localhost";
    public static final String DB_NAME = "bookshopdb";
    public static final String DB_USERNAME = "root";
    public static final String DB_PASSWORD = "12345";

    // Image path
    public static final String IMAGE_PATH = "/images";
}
